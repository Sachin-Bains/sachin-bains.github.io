# Deterministic limit-order matching engine

C++20 reconstruction, October 2026. The original project was documented in 2025 but its source is unavailable. This repository establishes a new implementation and new verification evidence. It does not recover historical benchmarks or establish a lock-free allocator.

## Contract

- One instrument; one serial command writer; integer price ticks and quantities.
- Price ticks 1–20,000 inclusive; display tick size 0.01. This is a bounded demonstrator, not an unrestricted exchange.
- IDs 1–2,147,483,647; quantity 1–1,000,000; capacity 1–4,096 active records.
- Buy executes cheapest eligible ask; sell executes highest eligible bid. FIFO within price. Executions use the resting price.
- Active IDs are unique. IDs can be reused after the prior order fully fills or is cancelled.
- Reserve an incoming slot before matching. Full capacity rejects even a fully crossing order, without mutating the resting book.
- Residual limit quantity rests at its limit. A partial maker retains its queue position. No market orders or amendment semantics are implemented.
- Every command increments command sequence, including rejected commands. Events have monotonically increasing sequence numbers until explicit reset.
- Reset clears the book, events and sequence counters. It is a laboratory/replay operation, not an order amendment.

## Data structures and memory

`Engine` owns fixed arrays: dense levels on each side, occupancy bitmaps, intrusive order records, a free-slot stack, an 8,192-bucket open-addressed ID index and a bounded last-command event buffer. Backward-shift deletion avoids accumulating tombstones. Occupied load cannot exceed 50%. No command path dynamically allocates; storage is established when the engine is created. This trades a bounded price range and reserved memory for predictable storage behaviour.

Known-level append and known-record unlink are O(1). ID operations are expected O(1), with collision-dependent worst cases. Best-price search scans bitmap words: O(R/64) worst case. Matching depends on consumed orders and repeated best-price searches. Snapshot serialisation and the full invariant scanner are separate inspection work, excluded from native command timing.

The engine is not thread-safe. Do not call the pool lock-free. This is not a live exchange, networking gateway, risk system or production market-data implementation.

## Internal execution inspection

An optional observer records reservation, maker selection, post-fill state, completion, cancellation and rejection. The C ABI copies these states into a fixed inspection buffer. Intermediate frames can contain an in-flight incoming record outside the resting queues; their final-book invariant is deliberately marked deferred, not failed or passed. Completed frames carry an invariant result. The actual command still executes atomically; a browser slider inspects captured states rather than pausing the native engine.

Inspection supports capacity up to 128 and retains at most 128 stages. On overflow the early stages plus a final frame are retained and truncation is explicit. Higher capacities are flagged as unsupported for capture. The matching core itself still supports 4,096 records. The observer is disabled for native measurements. API snapshot/trace buffers are outside the `sizeof(Engine)` structural memory account.

`book_index` exposes occupied ID-index buckets, home addresses, probe distances and slots for inspection. The collision experiment creates deliberate wrapped clusters and reads the index before and after actual cancellation; JavaScript does not implement the index repair.

## Native build and verification

With a C++20 compiler and CMake:

```
cmake -S . -B build-cmake -DCMAKE_BUILD_TYPE=Release
cmake --build build-cmake --config Release
ctest --test-dir build-cmake -C Release --output-on-failure
```

The verified build on this computer uses `scripts/build-native.cmd`, MSVC 19.39 with `/std:c++20 /O2 /EHsc /W4`. The script's Visual Studio location is specific to this machine; use the CMake route or update the location elsewhere. Run `build/engine_tests.exe`, `build/replay.exe` and `build/bench.exe`.

The tests cover both matching directions, price/FIFO ordering, partial fills, multi-level sweeps, queue cancellations, invalid fields, duplicates, resource exhaustion, price boundaries and record recycling. Five seeded generated workloads compare every command's trades and active book against an independent linear reference. Invariants check links, time order, aggregates, occupancy, free/active partition, lookup consistency and uncrossed resting prices. A separate workload instruments global allocation calls while issuing commands.

## Replay protocol

One command per input line; one JSON post-command snapshot per output line:

```
RESET 128
ADD 1 1 10100 50
ADD 2 1 10100 70
ADD 3 1 10150 100
ADD 4 0 10100 100
CANCEL 2
```

`ADD id side price_ticks quantity`; side 0 = buy, 1 = sell. The website downloads the same command arrays with its retained events and final snapshot. The UI retains the latest 200 events; exported commands preserve the complete current session.

To check a downloaded browser session against the native build, run `python scripts/replay-json.py matching-replay.json`. It sends the recorded commands to the native executable and requires exact equality with the browser's final JSON state. An optional second argument selects another replay executable location.

## Browser build

The portable core is compiled to WebAssembly with Emscripten. The UI invokes the C ABI from `src/api.cpp`; there is no JavaScript matching fallback. `scripts/build-wasm.py` currently locates the workspace SDK in `../work/emsdk` and the portfolio in the adjacent site folder. Adapt those paths outside this workspace. Exports: `book_reset`, `book_submit`, `book_cancel`, `book_snapshot`.

`scripts/test-wasm.mjs` compares native and WebAssembly JSON snapshots exactly over 1,010 commands, including event sequence, slot identity and queue links. `scripts/test-ubsan.py` compiles and runs the C++ test suite with undefined-behaviour instrumentation in WebAssembly. Native Windows AddressSanitizer failed interception during initialisation on this machine; no successful native ASan result is claimed. `scripts/test-asan.cmd` retains the attempted reproducible command.

## Measurements

The benchmark uses `std::chrono::steady_clock`. Four fixtures measure insertion into an empty level, cancellation, a one-maker match and an eight-level sweep. Each has 2,000 warm-ups followed by 20,000 individual command timings. Setup and cleanup are outside each window. Clock overhead is included. Full sorted observations and p50/p95/p99 are exported. Single timings quantise, sometimes to zero; zero readings are below the measurement granularity, not zero execution cost.

These are unpinned local Windows measurements on an Intel Core i7-12700H, not exchange SLA estimates. They do not establish performance under contention, network load, a different occupancy distribution or production risk checks. The separate paired insertion/cancellation throughput measurement is a different workload and must not be substituted for a distributional latency result.

`benchmarks/depth.cpp` adds 16 controlled fixtures, each with 500 warm-ups and 5,000 timed commands: sweeps consuming 1/4/16/64 makers at distinct prices, and known-ID cancellations in books with 16/128/512/1,024 orders across 1/8/16 levels. Cancellation reinsertion is outside the window; after its first iteration the chosen order is at the level tail. Native `sizeof` values accompany these measurements for an explicit fixed-storage account. The portfolio selects measured fixtures and quantiles without interpolating new timings.

The browser workload instrument runs a separate C++ instance with seeded synthetic commands. Every command checks the book invariant and the identity `accepted quantity = 2 * executed trade quantity + cancelled quantity + resting quantity`. Each trade consumes both maker and taker order quantity, explaining the factor of two. Exported workloads replay with `scripts/replay-json.py` and do not alter the main guided book. The seeded generator is a controlled software stress fixture, not a statistical market model or a native latency benchmark.

## Source map

`include/engine.hpp`: records, ownership and API. `src/engine.cpp`: index, pool, queue and matching. `src/api.cpp`: bounded numeric JSON snapshot bridge. `src/replay.cpp`: native stdin replay. `tests/tests.cpp`: independent reference and allocation instrumentation. `benchmarks/bench.cpp`: native measurement harness. The portfolio's JavaScript handles rendering and controls only.
