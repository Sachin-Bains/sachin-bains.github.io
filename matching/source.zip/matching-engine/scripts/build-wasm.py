from pathlib import Path
import os, subprocess, sys
root=Path(__file__).resolve().parents[2]
project=root/'matching-engine';sdk=root/'work/emsdk'
out=root/'sachin-portfolio-v3/sachin-portfolio-v3/matching';out.mkdir(exist_ok=True)
env=dict(os.environ,EM_CONFIG=str(sdk/'.emscripten'))
args=[sys.executable,str(sdk/'upstream/emscripten/em++.py'),'-std=c++20','-O2','-I'+str(project/'include'),str(project/'src/engine.cpp'),str(project/'src/api.cpp'),'-o',str(out/'engine.js'),'-sMODULARIZE=1','-sEXPORT_ES6=1','-sENVIRONMENT=web,node','-sFILESYSTEM=0','-sINITIAL_MEMORY=16777216','-sEXPORTED_FUNCTIONS=["_book_reset","_book_submit","_book_cancel","_book_snapshot","_book_trace_enable","_book_trace","_book_index"]','-sEXPORTED_RUNTIME_METHODS=["ccall","UTF8ToString"]']
subprocess.run(args,env=env,check=True)


