import createEngine from '../../sachin-portfolio-v3/sachin-portfolio-v3/matching/engine.js';
import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
const core=await createEngine();let seed=12345;const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed};
const commands=[['RESET',32],['ADD',1,1,10100,50],['ADD',2,1,10100,70],['ADD',3,1,10150,100],['ADD',4,0,10100,100]];
for(let i=0;i<1000;i++){if(i%200===0)commands.push(['RESET',16]);commands.push(random()%4===0?['CANCEL',random()%50+1]:['ADD',random()%50+1,random()%2,9900+random()%20,random()%100+1]);}
const native=spawnSync(fileURLToPath(new URL('../build/replay.exe',import.meta.url)),{input:commands.map(c=>c.join(' ')).join('\n')+'\n',encoding:'utf8',maxBuffer:30000000});assert.equal(native.status,0,native.stderr);const expected=native.stdout.trim().split(/\r?\n/).map(JSON.parse);
commands.forEach((c,i)=>{if(c[0]==='RESET')core._book_reset(c[1]);else if(c[0]==='ADD')core._book_submit(...c.slice(1));else core._book_cancel(c[1]);assert.deepEqual(JSON.parse(core.UTF8ToString(core._book_snapshot())),expected[i],`command ${i}`)});
core._book_trace_enable(1);core._book_reset(128);core._book_submit(1,1,10100,50);core._book_submit(2,1,10100,70);core._book_submit(3,1,10150,100);core._book_submit(4,0,10100,100);
const trace=JSON.parse(core.UTF8ToString(core._book_trace()));assert.deepEqual(trace.frames.map(f=>f.phase),[0,1,2,1,2,3]);assert.equal(trace.frames[2].orders.find(o=>o.slot===trace.frames[2].incoming).qty,50);assert.equal(trace.frames[4].orders.find(o=>o.id===2).qty,20);assert.equal(trace.frames[0].valid,null);assert.equal(trace.frames[5].valid,true);
core._book_reset(128);for(let i=1;i<=127;i++)core._book_submit(i,1,10000,1);core._book_submit(1000,0,10000,127);const limited=JSON.parse(core.UTF8ToString(core._book_trace()));assert.equal(limited.frames.length,128);assert.equal(limited.truncated,true);assert.equal(limited.frames.at(-1).phase,3);assert.equal(limited.frames.at(-1).valid,true);
core._book_reset(129);core._book_submit(1,1,10000,1);assert.equal(JSON.parse(core.UTF8ToString(core._book_trace())).truncated,true);
const report={passed:true,commands:commands.length,comparison:'Exact JSON equality: trades, state, slots, links, sequences and invariant result',seed:12345,inspection:{fifoFrames:6,intermediateInvariantDeferred:true,traceLimitAndFinalFrameVerified:true,unsupportedCapacityFlagged:true}};writeFileSync(fileURLToPath(new URL('../build/wasm-parity.json',import.meta.url)),JSON.stringify(report,null,2));console.log(JSON.stringify(report));

