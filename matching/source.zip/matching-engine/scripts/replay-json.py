"""Verify a browser-exported session against the native engine; never invoke a shell."""
from pathlib import Path
import json, subprocess, sys

data=json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
commands=data['commands'];lines=[]
for command in commands:
    if not isinstance(command,list) or not command or command[0] not in ['RESET','ADD','CANCEL']:
        raise ValueError('Unsupported command')
    if len(command)!={'RESET':2,'ADD':5,'CANCEL':2}[command[0]]:
        raise ValueError('Invalid argument count')
    if not all(type(x) is int and -2147483648<=x<=2147483647 for x in command[1:]):
        raise ValueError('Arguments must be signed 32-bit integers')
    lines.append(' '.join(map(str,command)))
binary=Path(sys.argv[2]) if len(sys.argv)>2 else Path(__file__).resolve().parents[1]/'build/replay.exe'
run=subprocess.run([str(binary)],input='\n'.join(lines)+'\n',text=True,capture_output=True,check=True)
states=run.stdout.strip().splitlines()
if len(states)!=len(commands):raise RuntimeError('Replay output count differs')
if json.loads(states[-1])!=data['finalState']:raise RuntimeError('Final state differs from browser export')
print(f'PASS: {len(commands)} commands replayed; native final state exactly matches browser export.')
