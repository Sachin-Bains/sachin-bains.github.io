from pathlib import Path
import subprocess, os, sys
root=Path(__file__).resolve().parents[2];sdk=root/'work/emsdk';project=root/'matching-engine'
env=dict(os.environ,EM_CONFIG=str(sdk/'.emscripten'))
subprocess.run([sys.executable,str(sdk/'upstream/emscripten/em++.py'),'-std=c++20','-O1','-fsanitize=undefined','-fno-sanitize-recover=all','-I'+str(project/'include'),str(project/'src/engine.cpp'),str(project/'tests/tests.cpp'),'-sENVIRONMENT=node','-sEXIT_RUNTIME=1','-sSTACK_SIZE=1048576','-o',str(project/'build/tests-ubsan.cjs')],env=env,check=True)
with (project/'build/ubsan-result.json').open('w') as f:
    subprocess.run([str(sdk/'node/24.19.0_64bit/node.exe'),str(project/'build/tests-ubsan.cjs')],stdout=f,check=True)
print((project/'build/ubsan-result.json').read_text())
