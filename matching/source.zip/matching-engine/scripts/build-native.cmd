@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cd /d "%~dp0.."
if not exist build mkdir build
cl /nologo /std:c++20 /O2 /EHsc /W4 /Iinclude /Fo:build/ /Fe:build/engine_tests.exe src/engine.cpp tests/tests.cpp
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /O2 /EHsc /W4 /Iinclude /Fo:build/ /Fe:build/replay.exe src/engine.cpp src/api.cpp src/replay.cpp
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /O2 /EHsc /W4 /Iinclude /Fo:build/ /Fe:build/bench.exe src/engine.cpp benchmarks/bench.cpp
if errorlevel 1 exit /b 1
cl /nologo /std:c++20 /O2 /EHsc /W4 /Iinclude /Fo:build/ /Fe:build/depth.exe src/engine.cpp benchmarks/depth.cpp
exit /b %errorlevel%

