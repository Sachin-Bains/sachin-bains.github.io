@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 exit /b 1
cd /d "%~dp0.."
cl /nologo /std:c++20 /O1 /EHsc /fsanitize=address /Zi /Iinclude /Fo:build/ /Fe:build/tests_asan.exe src/engine.cpp tests/tests.cpp
if errorlevel 1 exit /b 1
build\tests_asan.exe
